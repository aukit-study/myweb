// app/api/auth/[...nextauth]/route.ts
import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import pool from "@/lib/db"

const handler = NextAuth({
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const conn = await pool.getConnection()
        try {
          const [rows] = await conn.query(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            [credentials?.username, credentials?.password]
          )
          if ((rows as any[]).length > 0) {
            return { id: rows[0].id, name: rows[0].username }
          }
          return null
        } finally {
          conn.release()
        }
      },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/login",
  },
})

export { handler as GET, handler as POST }
