// app/layout.tsx
import './globals.css'
import { SessionProvider } from 'next-auth/react'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'My App',
  description: 'Next.js app with authentication',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gradient-to-r from-blue-500 to-indigo-600 min-h-screen text-white font-sans">
        <SessionProvider>{children}</SessionProvider>
      </body>
    </html>
  )
}
